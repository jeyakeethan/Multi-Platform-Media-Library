<?php
    header("Access-Control-Allow-Origin: *");
   // Define database connection parameters
   $hn      = '37.59.55.185:3306';
   $un      = 'qsrsEnzGc4';
   $pwd     = 'eMLeNut1SQ';
   $db      = 'qsrsEnzGc4';
   $cs      = 'latin1';

   // Set up the PDO parameters
   $dsn 	= "mysql:host=" . $hn . ";dbname=" . $db . ";charset=" . $cs;
   $opt 	= array(
                        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
                        PDO::ATTR_EMULATE_PREPARES   => false,
                       );
   // Create a PDO instance (connect to the database)
   $pdo 	= new PDO($dsn, $un, $pwd, $opt);
   $data    = array();
   $id = $_GET['id'];
   if($_GET['mode']=='songs'){
           try {
              $stmt 	= $pdo->query("SELECT name, song_id AS id FROM users NATURAL JOIN user_song NATURAL JOIN songs WHERE user_id=$id;");
              $str = "";
              while($row  = $stmt->fetch(PDO::FETCH_OBJ))
              {
                  $song_id = $row->id;
                  if(!file_exists("MediaLibrary/Songs/".$song_id.".mp3")){
                      $str.= $song_id."^".$row->name."#";
                  }
              }
        	echo $str;
           }
           catch(PDOException $e)
           {
              echo $e->getMessage();
           }
       }
       else if ($_GET['mode']=='movies'){
           try {
              $stmt 	= $pdo->query("SELECT name, movie_id AS id FROM users NATURAL JOIN user_movie NATURAL JOIN movies WHERE user_id=$id;");
              $str = "";
              while($row  = $stmt->fetch(PDO::FETCH_OBJ))
              {
                  $movie_id = $row->id;
                  if(!file_exists("MediaLibrary/Movies/".$movie_id.".mp4")){
                      $str.= $movie_id."^".$row->name."#";
                  }
              }
        	echo $str;
           }
           catch(PDOException $e)
           {
              echo $e->getMessage();
           }
       }
       else if (strtolower($_GET['mode'])=='pdfs'){
           try {
              $stmt 	= $pdo->query("SELECT name, PDF_id AS id FROM users NATURAL JOIN user_PDF NATURAL JOIN PDFs WHERE user_id=$id;");
              $str = "";
              while($row  = $stmt->fetch(PDO::FETCH_OBJ))
              {
                  $pdf_id = $row->id;
                  if(!file_exists("MediaLibrary/PDFs/".$pdf_id.".pdf")){
                      $str.= $pdf_id."^".$row->name."#";
                  }
              }
        	echo $str;
           }
           catch(PDOException $e)
           {
              echo $e->getMessage();
           }
       }

?>