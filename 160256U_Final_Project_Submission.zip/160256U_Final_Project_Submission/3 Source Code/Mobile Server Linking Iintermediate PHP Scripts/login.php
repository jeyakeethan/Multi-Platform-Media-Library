<?php
    header("Access-Control-Allow-Origin: *");
   // Define database connection parameters
   $hn      = '37.59.55.185:3306';
   $un      = 'qsrsEnzGc4';
   $pwd     = 'eMLeNut1SQ';
   $db      = 'qsrsEnzGc4';
   $cs      = 'latin1';

   // Set up the PDO parameters
   $dsn 	= "mysql:host=" . $hn . ";port=3306;dbname=" . $db . ";charset=" . $cs;
   $opt 	= array(
                        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
                        PDO::ATTR_EMULATE_PREPARES   => false,
                       );
   // Create a PDO instance (connect to the database)
   $pdo 	= new PDO($dsn, $un, $pwd, $opt);
   $json    =  file_get_contents('php://input');
   $obj     =  json_decode($json,true);
   $user = strtolower($obj['username']);
   $pass = MD5($obj['password']);
   
function m_log($arMsg)  
{  
	//define empty string                                 
	$stEntry="";  
	//get the event occur date time,when it will happened  
	$arLogData['event_datetime']='['.date('D Y-m-d h:i:s A').'] [client '.$_SERVER['REMOTE_ADDR'].']';  
	//if message is array type  
	if(is_array($arMsg))  
	{  
	//concatenate msg with datetime  
	foreach($arMsg as $msg)  
	$stEntry.=$arLogData['event_datetime']." ".$msg."rn";  
}  
else  
{   //concatenate msg with datetime  
	
	$stEntry.=$arLogData['event_datetime']." ".$arMsg."rn";  
}  
//create file with current date name  
$stCurLogFileName='log_'.date('Ymd').'.txt';  
//open the file append mode,dats the log file will create day wise  
$fHandler=fopen(LOG_PATH.$stCurLogFileName,'a+');  
//write the info into the file  
fwrite($fHandler,$stEntry);  
//close handler  
fclose($fHandler);  
}

m_log($user);m_log($pass);

   try {
          $stmt 	= $pdo->query("SELECT username AS name, user_id AS id FROM users WHERE username = '$user' AND password = '$pass' LIMIT 1");
          $data[]  = $stmt->fetch(PDO::FETCH_OBJ);

         echo '{
        "data":';
          // Return data as JSON
          echo json_encode($data);
    	echo '}';
       }
       catch(PDOException $e)
       {
          echo $e->getMessage();
       }

?>