<?php
header("Access-Control-Allow-Origin: *");
   // Define database connection parameters
   $hn      = '37.59.55.185:3306';
   $un      = 'qsrsEnzGc4';
   $pwd     = 'eMLeNut1SQ';
   $db      = 'qsrsEnzGc4';
   $cs      = 'latin1';

   // Set up the PDO parameters
   $dsn 	= "mysql:host=" . $hn . ";port=3306;dbname=" . $db . ";charset=" . $cs;
   $opt 	= array(
                        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
                        PDO::ATTR_EMULATE_PREPARES   => false,
                       );
   // Create a PDO instance (connect to the database)
   $pdo 	= new PDO($dsn, $un, $pwd, $opt);


   // Retrieve the posted data
   $json    =  file_get_contents('php://input');
   $obj     =  json_decode($json,true);
   $key     =  $obj["key"];

function m_log($arMsg)  
{  
	//define empty string                                 
	$stEntry="";  
	//get the event occur date time,when it will happened  
	$arLogData['event_datetime']='['.date('D Y-m-d h:i:s A').'] [client '.$_SERVER['REMOTE_ADDR'].']';  
	//if message is array type  
	if(is_array($arMsg))  
	{  
	//concatenate msg with datetime  
	foreach($arMsg as $msg)  
	$stEntry.=$arLogData['event_datetime']." ".$msg."rn";  
}  
else  
{   //concatenate msg with datetime  
	
	$stEntry.=$arLogData['event_datetime']." ".$arMsg."rn";  
}  
//create file with current date name  
$stCurLogFileName='log_'.date('Ymd').'.txt';  
//open the file append mode,dats the log file will create day wise  
$fHandler=fopen(LOG_PATH.$stCurLogFileName,'a+');  
//write the info into the file  
fwrite($fHandler,$stEntry);  
//close handler  
fclose($fHandler);  
}

//m_log($json);

   // Determine which mode is being requested
   switch($key)
   {
        
      // Add a new record to the technologies table
      case "create":
	        
         // Sanitise URL supplied values
         $itemId 	= 	$obj["id"];
		 $sharedId 	=	$obj["user"];
         $mode	  	= 	$obj["mode"];
		//m_log($itemId);
	//	m_log($sharedId);
	//	m_log($mode);
				 // Attempt to run PDO prepared statement
		 try {
			 switch($mode){
				case 0:
					$sql 	= "INSERT INTO user_song(user_id, song_id) VALUES((SELECT user_id FROM users WHERE username=:user), :item)";
					break;
				case 1:
					$sql 	= "INSERT INTO user_movie(user_id, movie_id) VALUES((SELECT user_id FROM users WHERE username=:user), :item)";
					break;
				case 2:
					$sql 	= "INSERT INTO user_PDF(user_id, PDF_id) VALUES((SELECT user_id FROM users WHERE username=:user), :item)";
					break;
			 }
			// m_log($sql);
			$stmt 	= $pdo->prepare($sql);
			$stmt->bindParam(':user', $sharedId, PDO::PARAM_INT);
			$stmt->bindParam(':item', $itemId, PDO::PARAM_INT);
			$stmt->execute();
			echo json_encode(array('message' => 'Congratulations successfully shared!'));
		 }
		 // Catch any errors in running the prepared statement
		 catch(PDOException $e)
		 {
			m_log($e->getMessage());
		 }
      break;



      // Update an existing record in the technologies table
      case "update":

         // Sanitise URL supplied values
         $name 		     = filter_var($obj->name, FILTER_SANITIZE_STRING, FILTER_FLAG_ENCODE_LOW);
         $description	  = filter_var($obj->description, FILTER_SANITIZE_STRING, FILTER_FLAG_ENCODE_LOW);
         $recordID	     = filter_var($obj->recordID, FILTER_SANITIZE_NUMBER_INT);

         // Attempt to run PDO prepared statement
         try {
            $sql 	= "UPDATE technologies SET name = :name, description = :description WHERE id = :recordID";
            $stmt 	=	$pdo->prepare($sql);
            $stmt->bindParam(':name', $name, PDO::PARAM_STR);
            $stmt->bindParam(':description', $description, PDO::PARAM_STR);
            $stmt->bindParam(':recordID', $recordID, PDO::PARAM_INT);
            $stmt->execute();

            echo json_encode('Congratulations the record ' . $name . ' was updated');
         }
         // Catch any errors in running the prepared statement
         catch(PDOException $e)
         {
            echo $e->getMessage();
         }

      break;



      // Remove an existing record in the technologies table
      case "delete":

         // Sanitise URL supplied values
         $itemId 	= 	$obj["id"];
         $mode	  	= 	$obj["mode"];

         // Attempt to run PDO prepared statement
         try {
             switch($mode){
				case 0:
					$sql 	= "DELETE FROM songs WHERE song_id=:id LIMIT 1;";
					break;
				case 1:
					$sql 	= "DELETE FROM movies WHERE movie_id=:id LIMIT 1;";
					break;
				case 2:
					$sql 	= "DELETE FROM PDFs WHERE PDF_id=:id LIMIT 1;";
					break;
			 }
            $stmt 	= $pdo->prepare($sql);
            $stmt->bindParam(':id', $itemId, PDO::PARAM_INT);
            $stmt->execute();

            echo json_encode('Congratulations the record ' .$itemId. ' was removed');
         }
         // Catch any errors in running the prepared statement
         catch(PDOException $e)
         {
            echo $e->getMessage();
         }

      break;
   }

?>