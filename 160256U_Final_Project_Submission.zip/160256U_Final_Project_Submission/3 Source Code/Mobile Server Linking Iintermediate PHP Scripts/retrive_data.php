<?php
header("Access-Control-Allow-Origin: *");
   // Define database connection parameters
   $hn      = '37.59.55.185:3306';
   $un      = 'qsrsEnzGc4';
   $pwd     = 'eMLeNut1SQ';
   $db      = 'qsrsEnzGc4';
   $cs      = 'latin1';

   // Set up the PDO parameters
   $dsn 	= "mysql:host=" . $hn . ";dbname=" . $db . ";charset=" . $cs;
   $opt 	= array(
                        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
                        PDO::ATTR_EMULATE_PREPARES   => false,
                       );
   // Create a PDO instance (connect to the database)
   $pdo 	= new PDO($dsn, $un, $pwd, $opt);
   $data    = array();


   // Attempt to query database table and retrieve data
   if(isset($_GET['mode'])&&isset($_GET['id'])){
       $id=$_GET['id'];
       if($_GET['mode']=='songs'){
           try {
              $stmt 	= $pdo->query("SELECT name, album, artist, duration, song_id AS id, size FROM users NATURAL JOIN user_song NATURAL JOIN songs WHERE user_id=$id ORDER BY name ASC");
              while($row  = $stmt->fetch(PDO::FETCH_OBJ))
              {
                 // Assign each row of data to associative array
                 $data[] = $row;
              }
        	
        	echo '{
            "data":';
              // Return data as JSON
              echo json_encode($data);
        	echo '}';
           }
           catch(PDOException $e)
           {
              echo $e->getMessage();
           }
       }
       else if ($_GET['mode']=='movies'){
           try {
              $stmt 	= $pdo->query("SELECT name, date, duration, movie_id AS id, size FROM users NATURAL JOIN user_movie NATURAL JOIN movies WHERE user_id=$id ORDER BY name ASC");
              while($row  = $stmt->fetch(PDO::FETCH_OBJ))
              {
                 // Assign each row of data to associative array
                 $data[] = $row;
              }
        	
        	echo '{
            "data":';
              // Return data as JSON
              echo json_encode($data);
        	echo '}';
           }
           catch(PDOException $e)
           {
              echo $e->getMessage();
           }
       }
       else if ($_GET['mode']=='PDFs'){
           try {
              $stmt 	= $pdo->query("SELECT name, author, date, size, PDF_id AS id FROM users NATURAL JOIN user_PDF NATURAL JOIN PDFs WHERE user_id=$id  ORDER BY name ASC");
              while($row  = $stmt->fetch(PDO::FETCH_OBJ))
              {
                 // Assign each row of data to associative array
                 $data[]=$row;
              }
        	
        	echo '{
            "data":';
              // Return data as JSON
              echo json_encode($data);
        	echo '}';
           }
           catch(PDOException $e)
           {
              echo $e->getMessage();
           }
       }
   }
   ?>