<?php
$mode = $_POST['mode'];
$id = $_POST['id'];
$target_dir = "MediaLibrary/".$mode."/";
$ext="";
switch($mode){
	case "Songs":
	$ext = ".mp3";
	break;
	case "Movies":
	$ext = ".mp4";
	break;
	case "PDFs":
	$ext = ".pdf";
	break;
}
$newname = $id.$ext;
$target_file = $target_dir.$newname;
$uploadOk = 1;

// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
move_uploaded_file($_FILES["upfile"]["tmp_name"], $target_file);
?>
