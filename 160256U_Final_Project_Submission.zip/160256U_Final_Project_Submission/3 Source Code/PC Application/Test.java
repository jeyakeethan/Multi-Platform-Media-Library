public class Test {
    public static void main(String[] args) {
        ServerConnection serverConnection= new ServerConnection();
        serverConnection.getMissedFiles("songs");
    }
}
