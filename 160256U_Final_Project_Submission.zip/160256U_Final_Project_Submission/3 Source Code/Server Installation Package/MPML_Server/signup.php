<?php 

if(isset($_POST['phone'])){
		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
		$email = $_POST['email'];
		$street = $_POST['street'];
		$city = $_POST['city'];
		$zip = $_POST['zip'];
		$phone = $_POST['phone'];
		$conn = mysqli_connect("localhost", "root", "", "mpml");
		$username = $_POST['username'];
		$password = $_POST['password'];
		echo signup($firstname, $lastname, $email, $street, $city, $zip, $phone, $conn, $username, $password);
		mysqli_close($conn);
}
function signup($first, $last, $email, $street, $city, $zip, $phone, $conn, $user, $pass){
	$pass = MD5($pass);
	$response ="";
	$date = date('Y-m-d H:i:s');
	$query = mysqli_prepare($conn,"INSERT INTO users (username, password, email, street, city, first_name, last_name, date_joined)VALUES (?,?,?,?,?,?,?,?)");
	$query0=mysqli_stmt_bind_param($query, "ssssssss",$user, $pass, $email, $street, $city, $first, $last, $date);
	$result =mysqli_stmt_execute($query);
	$user_id = mysqli_fetch_row(mysqli_query($conn, "SELECT LAST_INSERT_ID();"))[0];
	if($result){
		setcookie("user_id", $user_id, time()+345600);
		setcookie("user", $user, time()+345600);
		setcookie("pass", $pass, time()+345600);
		$response=$response+"You have signed up successfully. ";
		header("Location: home.php");
	}
	else{
		die("something went wrong.");
	}
	return $response;
}

?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Sign Up | MPML</title>

    <!-- Favicon  -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="css/core-style.css">
    <link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="stylesheet" type="text/css" href="styles/main_styles.css">

</head>

<body>

    <!-- ##### Main Content Wrapper Start ##### -->
    <div class="main-content-wrapper d-flex clearfix">

        <!-- Mobile Nav (max width 767px)-->
        <div class="mobile-nav">
            <!-- Navbar Brand -->
            <div class="logo"><a href="index.php">Media Library</a></div>
            <!-- Navbar Toggler -->
            <div class="amado-navbar-toggler">
                <span></span><span></span><span></span>
            </div>
        </div>

        <!-- Header Area Start -->
        <header class="header-area clearfix" style="margin-top:-35px;">
            <!-- Close Icon -->
            <div class="nav-close">
                <i class="fa fa-close" aria-hidden="true"></i>
            </div>
            <!-- Logo -->
            <div class="logo" min-width="450"><a href="index.php">Media Library</a></div>
		</header>

        <!-- Header Area End -->
		<div align="center" style="margin:-100px 0 0 50px;">
			<div class="cart-table-area" style="padding:0 100px 100px 100px;">
				<div class="container-fluid">
					<div class="row">
						<div class="">
							<div class="checkout_details_area mt-50 clearfix">

								<div class="cart-title">
									<h2>Sign Up</h2>
								</div>
								
									<form action="#" method="post">
										<div class="row">
											<div class="col-md-6 mb-3">
												<input type="text" class="form-control" id="first_name" name="firstname"value="" placeholder="First Name" required>
											</div>
											<div class="col-md-6 mb-3">
												<input type="text" class="form-control" id="last_name" name="lastname"value="" placeholder="Last Name" required>
											</div>
											<div class="col-12 mb-3">
												<input type="email" class="form-control" id="email" name="email"placeholder="Email" value="" required>
											</div>
											<!--<div class="col-12 mb-3">
												<select class="w-100" id="country">
												<option value="usa">United States</option>
												<option value="uk">United Kingdom</option>
												<option value="ger">Germany</option>
												<option value="fra">France</option>
												<option value="ind">India</option>
												<option value="aus">Australia</option>
												<option value="bra">Brazil</option>
												<option value="cana">Canada</option>
											</select>
											</div>-->
											<div class="col-12 mb-3">
												<input type="text" class="form-control mb-3" id="street_address" name="street" placeholder="Address" value="" required>
											</div>
											<div class="col-12 mb-3">
												<input type="text" class="form-control" id="city" name="city"placeholder="Town" value="" required>
											</div>
											<div class="col-md-6 mb-3">
												<input type="text" class="form-control" id="zipCode"name="zip" placeholder="Zip Code" value="">
											</div>
											<div class="col-md-6 mb-3">
												<input type="number" class="form-control" id="phone_number" name="phone" min="0" placeholder="Phone No" value="" required>
											</div>
											<!--<div class="col-12 mb-3">
												<textarea name="comment" class="form-control w-100" id="comment" cols="30" rows="10" placeholder="Leave a comment about your order"></textarea>
											</div>-->
											<div class="col-12 mb-3">
												<input type="text" class="form-control" id="username" name="username" placeholder="User Name" value="" required>
											</div>
											<div class="col-12 mb-3">
												<input type="password" class="form-control" id="password" name="password" placeholder="Pass Word" value="" required>
											</div>
											<div class="col-12" align="left">
												
											</div>
										</div>
										<div class="container-login100-form-btn m-t-17">
											<button class="login100-form-btn" >
												Sign Up >>>
											</button>
										</div>
										</br>
										<a href="index.php" class="txt2">
											Login
										</a>
									</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div>
    <!-- ##### Main Content Wrapper End ##### -->


<div class="copyright" align="center">
		<div class="container">
			<div class="row">
				<div class="col">
					
				<div class="copyright_container d-flex flex-sm-row flex-column align-items-center justify-content-start"  align="center">
						<div class="copyright_content"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Media Library
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</div></div></div></div></div></div>
	
	
    <!-- ##### jQuery (Necessary for All JavaScript Plugins) ##### -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
	<!-- Custom js -->
    <script src="js/custom_signup.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
	<!-- Custom js -->
    <script type="text/JavaScript" src="js/custom_signup.js"></script>
</body>

</html>