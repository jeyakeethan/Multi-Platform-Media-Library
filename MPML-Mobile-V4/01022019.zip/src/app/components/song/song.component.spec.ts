import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { SongComponent } from './song.component';
import { File } from '@ionic-native/file';
describe('SongComponent', () => {
  let component: SongComponent;
  let fixture: ComponentFixture<SongComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports:[TableModule, DialogModule],
      declarations: [ SongComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SongComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
