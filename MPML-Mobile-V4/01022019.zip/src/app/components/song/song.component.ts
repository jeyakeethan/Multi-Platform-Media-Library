import { Component, OnInit} from '@angular/core';
import { File } from '@ionic-native/file/ngx';
import { FilePath } from '@ionic-native/file-path/ngx';
import { Platform } from '@ionic/angular';
import { MusicControls } from '@ionic-native/music-controls/ngx';

import {SongService} from '../../service/song.service';

export class Song{
  constructor(public name?, public album?, public artist?, public duration?, public onServer?, public path?){
  }
}

@Component({
  selector: 'app-song',
  templateUrl: './song.component.html',
  styleUrls: ['./song.component.scss'],
  providers:[File, FilePath,SongService]
})

export class SongComponent{
    songs :Song[];
    selectedSong:Song;
    display:boolean;
    items;
    savedParentNativeURLs = [];
    constructor(private file: File, private filePath: FilePath, private platform: Platform, private musicControls: MusicControls, private songService:SongService){
      this.songService.getSongs().then(songs=>this.songs=songs);
      this.display=false;

      const ROOT_DIRECTORY = 'file:///';
      platform.ready().then(() => {
        this.listDir(ROOT_DIRECTORY, '');
    })
    }
    ngOnInit(){}
    public deleteSong(index:number){
          this.songs.splice(index, 1);
    }

    public onRowSelect(event) {
      this.selectedSong = {...event.data};
      //this.displayDialog = true;
    }
    public showDisplay(){
      this.display=true;
    }

    listDir = (path, dirName) => {
      this.file
        .listDir(path, dirName)
        .then(entries => {
          this.items = entries;
        })
        .catch(this.handleError);
    };
    goDown = item => {
      const parentNativeURL = item.nativeURL.replace(item.name, "");
      this.savedParentNativeURLs.push(parentNativeURL);
    
      this.listDir(parentNativeURL, item.name);
    };
    goUp = () => {
      const parentNativeURL = this.savedParentNativeURLs.pop();
    
      this.listDir(parentNativeURL, "");
    };

    handleError = error => {
      console.log("error reading,", error);
    };
    getItems(event){
      /*// Reset items back to all of the items
      this.initializeItems();
      // set val to the value of the ev target
      var val = ev.target.value;
      // if the value is an empty string don't filter the items
      if (val && val.trim() != '') {
        this.items = this.items.filter((item) => {
          return (item.toLowerCase().indexOf(val.toLowerCase()) > -1);
        })
      }*/
    }
    sortItems(tag){
      switch(tag){
        case 'name':
          this.songs = this.songs.sort(function(a, b){
            if(a.name < b.name)return -1;else return 1;
          });
        break;
        case 'album':
          this.songs = this.songs.sort(function(a, b){
            if(a.album < b.album)return -1;else return 1;
          });
        break;
        case 'artist':
          this.songs = this.songs.sort(function(a, b){
            if(a.artist < b.artist)return -1;else return 1;
          });
        break;
        case 'duration':
          this.songs = this.songs.sort(function(a, b){
              return a.duration - b.duration;
          });
        break;
      }
    }
}
