import { Component, OnInit} from '@angular/core';
import { File } from '@ionic-native/file/ngx';
import { FilePath } from '@ionic-native/file-path/ngx';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-tab4',
  templateUrl: 'tab4.page.html',
  styleUrls: ['tab4.page.scss'],
  providers:[File]
})
export class Tab4Page {
  items;
  selectPath;
  savedParentNativeURLs = [];
  constructor(private file:File, private platform:Platform){
    this.selectPath = false;
      const ROOT_DIRECTORY = 'file:///';
      platform.ready()
      .then(() => {
        this.listDir(ROOT_DIRECTORY, '');
    })
  }

  listDir = (path, dirName) => {
    this.file
      .listDir(path, dirName)
      .then(entries => {
        this.items = entries;
      })
      .catch(this.handleError);
  };
  goDown = item => {
    const parentNativeURL = item.nativeURL.replace(item.name, "");
    this.savedParentNativeURLs.push(parentNativeURL);
  
    this.listDir(parentNativeURL, item.name);
  };
  goUp = () => {
    const parentNativeURL = this.savedParentNativeURLs.pop();
  
    this.listDir(parentNativeURL, "");
  };

  handleError = error => {
    console.log("error reading,", error);
  };

  selectSongDir(){
    this.selectPath=true;
  }
  selectMovieDir(){
    this.selectPath=true;
  }
  selectImageDir(){
    this.selectPath=true;
  }
}
