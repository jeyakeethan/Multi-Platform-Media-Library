(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab4-tab4-module"],{

/***/ "./src/app/tab4/tab4.module.ts":
/*!*************************************!*\
  !*** ./src/app/tab4/tab4.module.ts ***!
  \*************************************/
/*! exports provided: Tab4PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab4PageModule", function() { return Tab4PageModule; });
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _tab4_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tab4.page */ "./src/app/tab4/tab4.page.ts");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/file-path/ngx */ "./node_modules/@ionic-native/file-path/ngx/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};








var Tab4PageModule = /** @class */ (function () {
    function Tab4PageModule() {
    }
    Tab4PageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [
                _ionic_angular__WEBPACK_IMPORTED_MODULE_0__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild([{ path: '', component: _tab4_page__WEBPACK_IMPORTED_MODULE_5__["Tab4Page"] }])
            ],
            declarations: [_tab4_page__WEBPACK_IMPORTED_MODULE_5__["Tab4Page"]],
            providers: [_ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_6__["File"], _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_7__["FilePath"]]
        })
    ], Tab4PageModule);
    return Tab4PageModule;
}());



/***/ }),

/***/ "./src/app/tab4/tab4.page.html":
/*!*************************************!*\
  !*** ./src/app/tab4/tab4.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Settings</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n\n  <ion-item-divider>\n    <ion-label color=\"primary\">Song</ion-label>\n  </ion-item-divider>\n  <ion-button (click)=\"selectSongDir()\">Select song directories</ion-button>\n  <ion-item>Upload to servers&nbsp;<ion-checkbox></ion-checkbox></ion-item>\n\n  <ion-item-divider>\n    <ion-label color=\"primary\">Movie</ion-label>\n  </ion-item-divider>\n  <ion-button (click)=\"selectMovieDir()\">Select movie directories</ion-button>\n  <ion-item>Upload to servers&nbsp;<ion-checkbox></ion-checkbox></ion-item>\n  \n  <ion-item-divider>\n    <ion-label color=\"primary\">Image</ion-label>\n  </ion-item-divider>\n  <ion-button (click)=\"selectImageDir()\">Select image directories</ion-button>\n  <ion-item>Upload to servers&nbsp;<ion-checkbox></ion-checkbox></ion-item>\n  \n<div *ngIf=\"selectPath\">\n  <ion-item><ion-icon name=\"arrow-round-up\" (click)=\"goUp()\">...</ion-icon></ion-item>\n\n    <div *ngFor=\"let item of items\">\n\n      <div *ngIf=\"item.isDirectory\" (click)=\"goDown(item)\">\n        <ion-item><ion-icon name=\"folder\"></ion-icon>>{{item.name}}<ion-checkbox></ion-checkbox></ion-item>\n      </div>\n\n      <div *ngIf=\"item.isFile\">\n        <ion-item>File: {{item.name}}</ion-item>\n      </div>\n    </div>\n    <ion-button>\n      Save changes\n      <ion-icon slot=\"end\" name=\"save\"></ion-icon>\n    </ion-button>\n</div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/tab4/tab4.page.scss":
/*!*************************************!*\
  !*** ./src/app/tab4/tab4.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RhYjQvdGFiNC5wYWdlLnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/tab4/tab4.page.ts":
/*!***********************************!*\
  !*** ./src/app/tab4/tab4.page.ts ***!
  \***********************************/
/*! exports provided: Tab4Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab4Page", function() { return Tab4Page; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var Tab4Page = /** @class */ (function () {
    function Tab4Page(file, platform) {
        var _this = this;
        this.file = file;
        this.platform = platform;
        this.savedParentNativeURLs = [];
        this.listDir = function (path, dirName) {
            _this.file
                .listDir(path, dirName)
                .then(function (entries) {
                _this.items = entries;
            })
                .catch(_this.handleError);
        };
        this.goDown = function (item) {
            var parentNativeURL = item.nativeURL.replace(item.name, "");
            _this.savedParentNativeURLs.push(parentNativeURL);
            _this.listDir(parentNativeURL, item.name);
        };
        this.goUp = function () {
            var parentNativeURL = _this.savedParentNativeURLs.pop();
            _this.listDir(parentNativeURL, "");
        };
        this.handleError = function (error) {
            console.log("error reading,", error);
        };
        this.selectPath = false;
        var ROOT_DIRECTORY = 'file:///';
        platform.ready()
            .then(function () {
            _this.listDir(ROOT_DIRECTORY, '');
        });
    }
    Tab4Page.prototype.selectSongDir = function () {
        this.selectPath = true;
    };
    Tab4Page.prototype.selectMovieDir = function () {
        this.selectPath = true;
    };
    Tab4Page.prototype.selectImageDir = function () {
        this.selectPath = true;
    };
    Tab4Page = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-tab4',
            template: __webpack_require__(/*! ./tab4.page.html */ "./src/app/tab4/tab4.page.html"),
            providers: [_ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_1__["File"]],
            styles: [__webpack_require__(/*! ./tab4.page.scss */ "./src/app/tab4/tab4.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_1__["File"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]])
    ], Tab4Page);
    return Tab4Page;
}());



/***/ })

}]);
//# sourceMappingURL=tab4-tab4-module.js.map