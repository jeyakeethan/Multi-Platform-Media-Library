import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Song} from '../components/song/song.component';

@Injectable()
export class SongService {
  constructor(private httpClient:HttpClient) {}
    getSongs() {
      return this.httpClient.get<any>('assets/data/songs.json')
          .toPromise()
          .then(res => <Song[]> res.data)
          .then(data => data);
  }

  loadSongs(){
      return this.httpClient.get<any>('http://localhost/MPML/retrive_data.php')
      .toPromise()
      .then(res => <Song[]> res.data)
      .then(data => data);
   }
}
